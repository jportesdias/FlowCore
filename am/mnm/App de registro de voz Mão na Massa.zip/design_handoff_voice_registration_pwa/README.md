# Handoff: Registro de Voz — Mão na Massa Mobile (PWA)

## Overview
Módulo de coleta de dados por voz para o sistema de gestão **Mão na Massa**, com interação estilo WhatsApp. O usuário de campo (encarregado/gestor) grava uma nota de voz por obra; o sistema transcreve o áudio, usa IA para estruturar os dados (diário de obra, pedido de compra, consumo de material, ocorrência), o usuário revisa/edita os campos extraídos e envia. O lançamento entra em uma fila de **quarentena** até um gestor aprová-lo dentro do Mão na Massa.

Este pacote é para implementar o módulo como um **PWA (Progressive Web App)** instalável, dentro do projeto/ambiente já existente do Mão na Massa.

## About the Design Files
Os arquivos deste pacote são **referências de design feitas em HTML/React** (um protótipo clicável construído como Design Component) — mostram a intenção visual e comportamental, não são código de produção para copiar direto. A tarefa é **recriar este design no ambiente de código já existente do Mão na Massa** (o stack/framework atual do projeto), usando os padrões, componentes e infraestrutura já estabelecidos ali. Se o Mão na Massa ainda não tiver um front-end mobile/PWA, escolha o framework mais adequado (ex.: React + Vite/Next com plugin PWA, ou o que já for usado no restante do sistema) e implemente lá.

## Fidelity
**Alta fidelidade (hifi)** para layout, cores, tipografia, espaçamento e fluxo de telas — a moldura de iPhone é apenas para preview, não faz parte do produto final (o app real deve rodar em viewport mobile responsivo padrão, sem bezel). Os textos e o conjunto de "amostras de IA" (transcrição → dados extraídos) são dados fictícios para demonstrar o comportamento esperado — a IA real deve ser conectada em produção (ver seção IA/Backend).

## Screens / Views

### 1. Obras (Home)
- **Purpose**: lista as obras/projetos do usuário; ponto de entrada.
- **Layout**: header fixo no topo (padding top extra para status bar em app real, ~54px em iOS) com: label pequena uppercase "MÃO NA MASSA · MÓDULO DE VOZ" (11px, weight 700, letter-spacing 0.12em, cor accent-700), título "Obras" (fonte heading, 30px), subtítulo "Toque em uma obra para ver os registros de voz" (13px, neutral-600). Abaixo, lista vertical rolável de cards (gap ~13px, padding lateral ~18px).
- **Components — Card de obra** (`.card.elev-sm`, clicável):
  - Título da obra (`.card-title`)
  - Endereço (`.card-body`)
  - Linha meta: contagem total de registros (12px, neutral-600) + tag `tag-accent` "N pendentes" só se houver registros em quarentena.

### 2. Obra (histórico de registros)
- **Purpose**: histórico de notas de voz de uma obra, em bolhas estilo chat (alinhadas à direita, como mensagens enviadas).
- **Layout**: header com botão voltar (chevron-left) + nome da obra (fonte heading, 19px) + endereço (12px, neutral-600), borda inferior divider. Lista rolável de bolhas. Barra inferior fixa: pill cinza "Toque no microfone para gravar um novo registro" + botão circular de microfone (48px, bg accent, ícone branco) que abre a tela de Gravação.
- **Components — Bolha de registro** (`.card.elev-sm`, max-width 82%, alinhada à direita):
  - Círculo 34px bg accent com ícone de "play" branco
  - Mini waveform (14 barras finas, alturas variadas, bg neutral-400)
  - Duração (ex. "0:34", 12px, neutral-600)
  - Linha de tags: `tag-{accent-2|accent|neutral|outline}` para o tipo (Diário de obra / Pedido de compra / Consumo de materiais / Ocorrência) + `tag-{accent|accent-2|neutral}` para o status (Em quarentena / Aprovado / Rejeitado)
  - Timestamp (ex. "Hoje, 14:32", 11px, neutral-500, alinhado à direita)
  - Clique abre a tela de Detalhe do registro.

### 3. Gravação
- **Purpose**: capturar o áudio.
- **Layout**: tela cheia, botão X de cancelar no topo-esquerda. Centro: label "Registro de voz", botão circular grande (132px, bg accent) com ícone de microfone branco — toque inicia/para a gravação; enquanto grava, pulsa (halo com `box-shadow` animado, 1.4s ease-out infinite). Abaixo: timer mm:ss (fonte heading, 32px). Abaixo: 20 barrinhas de waveform animadas (só animam enquanto gravando — `animation-play-state: running/paused`). Texto de ajuda: "Toque para começar a gravar" / "Toque para enviar".
- **Behavior**: 1º toque inicia contagem (setInterval 1s); 2º toque para e navega para Processando.

### 4. Processando
- **Purpose**: feedback de transcrição/IA em andamento.
- **Layout**: centralizado, spinner circular (56px, borda 4px, rotação 0.9s linear infinite), texto de estágio: "Transcrevendo áudio…" (0–1.1s) depois "Estruturando dados com IA…" (1.1–2.3s). Após ~2.3s navega automaticamente para Revisar lançamento.

### 5. Revisar lançamento (resultado da IA)
- **Purpose**: usuário confere/edita os dados extraídos antes de enviar.
- **Layout**: header com X (descartar) + título "Revisar lançamento". Conteúdo: tag do tipo detectado; card "O que você disse" com a transcrição em itálico; card "Dados extraídos pela IA" com um `.field` + `.input` editável por campo (label + valor, todos editáveis); nota de rodapé explicando que o envio cai na fila de quarentena. Rodapé fixo: botão `.btn-ghost` "Descartar" + botão `.btn-primary` "Enviar para aprovação" (flex 1:2).
- **Behavior**: editar qualquer campo atualiza o estado local; "Enviar para aprovação" cria o registro com status `quarentena` e volta para a tela Obra, aparecendo no topo da lista.

### 6. Detalhe do registro
- **Purpose**: ver um registro já existente (gravado ou histórico).
- **Layout**: header com voltar + tipo. Linha de tags (tipo + status) e timestamp à direita. Card de status (ícone + texto conforme status — ver abaixo). Card de player: botão play/pause circular (44px, bg accent) + barra de progresso (6px, trilho neutral-300, preenchimento accent) + duração. Card "Transcrição" (itálico). Card "Dados extraídos pela IA" (linhas label/valor, somente leitura, com divisor `--color-divider` entre linhas).
- **Status card content**:
  - `quarentena`: ícone relógio (accent-700) — "Em quarentena — aguardando a aprovação de um gestor no Mão na Massa antes de entrar no sistema."
  - `aprovado`: ícone check (accent-2-700) — "Aprovado e lançado no Mão na Massa em {data}."
  - `rejeitado`: ícone X circular (neutral-600) — "Rejeitado pelo gestor. Motivo: {motivo}."
- **Behavior**: play/pause simula progresso (setInterval 100ms, 10 ticks/segundo de duração); em produção troca por `<audio>` real com o arquivo gravado.

## Interactions & Behavior
- Toda navegação é client-side, sem reload (troca de "tela" = troca de view/estado, dentro do mesmo shell mobile).
- Sem estados de erro/validação de formulário no protótipo — em produção, adicionar: falha de transcrição, falha de rede ao enviar, campo obrigatório vazio.
- Responsivo: protótipo fixado em viewport de iPhone (402×874) só para preview; a implementação real deve ser fluida (100vw/100vh mobile-first), com breakpoint opcional para tablet/desktop.
- Sem estado de loading de rede real (é tudo mock/timers) — substituir por chamadas assíncronas reais com estado de loading/erro.

## State Management
- `screen`: 'home' | 'obra' | 'recording' | 'processing' | 'result' | 'detail'
- `obras`: lista de obras, cada uma com `id`, `nome`, `endereco`, `registros[]`
- `registro`: `{ id, tipoLabel, transcricao, campos: [{label, value}], status: 'quarentena'|'aprovado'|'rejeitado', duracaoSeconds, dataHoraLabel, motivoRejeicao?, dataAprovacaoLabel? }`
- `draft`: registro em construção após a IA processar, antes do envio (mesma forma de `registro` sem `status`/`id`)
- `recording` (bool), `recordSeconds` (int, timer)
- `processingStage`: 0 (transcrevendo) | 1 (estruturando)
- `playing` (bool), `playProgress` (0–100)

### Fluxo de dados esperado em produção
1. Gravação real do microfone (MediaRecorder API / equivalente nativo) → blob de áudio.
2. Upload do áudio para o backend.
3. Backend chama um serviço de speech-to-text → transcrição.
4. Backend/IA classifica o tipo (diário de obra / pedido de compra / consumo de materiais / ocorrência) e extrai os campos estruturados correspondentes.
5. Front-end recebe `{transcricao, tipo, campos}` e mostra a tela "Revisar lançamento" para edição humana.
6. Ao confirmar, o registro é gravado com status `quarentena` (fila de aprovação) e replicado para o Mão na Massa via API/integração — só passa a valer no sistema de gestão depois que um gestor aprovar lá.
7. Atualizações de status (`aprovado`/`rejeitado`) vêm do Mão na Massa (webhook ou polling) e devem refletir no histórico.

## Design Tokens (Organic design system)
Ver `_ds/organic-851ce427-adbb-471d-a344-98e86c67406e/styles.css` incluído neste pacote — todos os valores abaixo vêm de lá, não devem ser reescritos como hex/px soltos no código de produção.

- **Cores**: `--color-bg` #f5ead8, `--color-text` #201e1d, `--color-accent` #c67139, `--color-accent-2` #7a8a5e, `--color-divider`, `--color-surface` #ebddc5, rampas `--color-neutral-100..900`, `--color-accent-100..900`, `--color-accent-2-100..900`.
- **Tipografia**: `--font-heading` (Caprasimo) para títulos, `--font-body` (Figtree) para o resto.
- **Espaçamento**: `--space-1` a `--space-8` (escala 4.4px–35.2px).
- **Raio**: `--radius-sm` 8px, `--radius-md` 16px, `--radius-lg` 28px; botões/pills usam 999px.
- **Sombra**: `--shadow-sm/md/lg`.
- **Componentes de classe** usados: `.card` (+`.card-title`,`.card-body`,`.card-kicker`,`.card-meta`,`.elev-sm`), `.tag` (+`.tag-accent`,`.tag-accent-2`,`.tag-neutral`,`.tag-outline`), `.btn` (+`.btn-primary`,`.btn-ghost`,`.btn-icon`), `.field`+`.input`.

## Assets
- Nenhum asset de imagem/foto usado neste módulo (é 100% dados + ícones).
- Ícones: estilo Lucide, `stroke-width: 2.75`, desenhados inline como SVG no protótipo (chevron-left, x, mic, play, pause, check, clock, x-circle). Em produção, trocar por uma lib de ícones Lucide real, mantendo o stroke-width 2.75 do design system.

## Files
- `Mão na Massa Mobile.dc.html` — protótipo completo (todas as 6 telas + lógica de estado/mock de IA). Abra num navegador para ver/interagir; use como referência de layout e comportamento, não como código a copiar 1:1 (é um formato proprietário de protótipo, não um componente React "puro").
- `_ds/organic-851ce427-adbb-471d-a344-98e86c67406e/` — design system Organic completo (styles.css com os tokens, guia, exemplos de componentes) usado neste protótipo.

## PWA — notas de implementação
- Web Push para notificar o gestor quando um item cai em quarentena requer: Service Worker registrado, permissão de notificação solicitada no onboarding, e um backend capaz de disparar push (VAPID keys ou serviço tipo Firebase Cloud Messaging).
- iOS Safari só suporta push a partir da versão 16.4, e apenas depois do usuário "Adicionar à Tela de Início" — considerar um aviso/onboarding explicando isso.
- Gravação de áudio via `navigator.mediaDevices.getUserMedia` + `MediaRecorder`; pedir permissão de microfone de forma explícita antes da primeira gravação (tela de onboarding não estava no escopo deste protótipo, mas é recomendada em produção).
- Manifest (`manifest.json`) com ícone e cor de tema usando `--color-accent` (#c67139) e `--color-bg` (#f5ead8) como `background_color`.
